
//Nasibullah Qarizada - 1900004691



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <pthread.h>
#include <fcntl.h>
#include <string.h>


char banner[] = "prj4p1.c creates 2 threads running under the main thread\n"
"           - create - copies lines from stdin to a file until EOF(ctrl + d) is entered\n"
"           - display - lists records stored in the file on \"/dev/pts/1\"\n"
"                       Open a new terminal; verify that it is \"/dev/pts/1\" with tty command, then\n"
"                          display the execution contex using the commands : \n";
  

int count=0;

char buf[120];

void* create ( )
{
  char File_n[] = "log.txt";
  int File_d;
  printf("create>\tTID <%u>\tPid <%d>\tPPid <%d> running\n",pthread_self(), getpid(), getppid());
  

        // create the output file & force outputs to be written on disk
         if((File_d = open( File_n, O_WRONLY | O_TRUNC | O_CREAT | O_SYNC,
                       S_IRUSR  |S_IWUSR)) == -1)
            {perror("open2"); exit(2);}
      
      while (fgets(buf, sizeof(buf)-1, stdin) != NULL)
           write(File_d, buf, strlen(buf));
  count=1;
       close(File_d);

  printf("\ncreate>\tTID <%u> exits", pthread_self () );
  return NULL;    // returns a NULL pointer

}

void *list(){

    char fn[] = "log.txt";
    int fpos;     // file size
        FILE *ptw;         // pseudo terminal window pointer
        FILE *inp;         // pseudo terminal window pointer
        struct stat file;  // Data structures used by stat function


printf("List>\tTID <%u> \tPid <%d>\tPPid <%d> running\n", pthread_self (), getpid(), getppid());



while (count==0)sleep(3);

if( (ptw = fopen( "/dev/pts/1", "w")) == NULL)
            {perror("open3"); exit(2);}

if( (inp = fopen( fn, "r")) == NULL)
            {perror("open3"); exit(2);}
fprintf(ptw,"\nlist thread starts now ... \n");

while (count++ < 4 ) {


            // get the size of the file
            if (stat(fn, &file) < 0)
                { perror("stat error"); exit(4);}
            // test if new data entered
            fpos= ftell(inp);
            if (file.st_size > fpos) {  // is there new records ??
                if ( (fgets (buf, 120-1, inp) ) == NULL) 
                     {perror("read2"); exit(6);}
                fputs (buf, ptw) ; 
                count=0;   // reset the count
            }
            else
                sleep(3);    // sleep n seconds
        }

printf("\nlist>\tTID <%u> exits", pthread_self () );
return NULL;


}

int main()
{
    puts(banner);
   printf("\t\t\t$ ps -Lf -p %d\n",getpid());
   printf("\t\t\tpstree -p %d\n",getppid());

  char fn[]="log.txt";
  pthread_t pTID, myThreads1, myThreads2;

  printf("\nMain>\tTID <%u>", pthread_self () );  
  printf("\tPid <%d>\tPPid <%d>\n", getpid(), getppid()); 

  if ( pthread_create(&myThreads1, NULL, create, NULL) != 0 )
      { perror ("pthread_crate");  return(1); }
  sleep(1);   // to let the thread run
  
 
	if ( pthread_create(&myThreads2, NULL, list, NULL) != 0 )
      { perror ("pthread_crate");  return(1); }
       sleep(1);

  pthread_join(myThreads1, NULL); /* wait for thread */  
  pthread_join(myThreads2, NULL); 
  printf("\nMain>\tTID <%u> exits\n", pthread_self () );
  pthread_exit(0);
  return 0;
}
