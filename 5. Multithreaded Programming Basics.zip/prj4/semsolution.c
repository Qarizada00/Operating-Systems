




//nasibullah qarizada - 1900004691
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <pthread.h>
#include <fcntl.h>
#include <string.h>
#include <semaphore.h>




char banner[] = "prj4p1.c creates 2 threads running under the main thread\n"
"           - create - copies lines from stdin to a file until EOF(ctrl + d) is entered\n"
"           - display - lists records stored in the file on \"/dev/pts/1\"\n"
"                       Open a new terminal; verify that it is \"/dev/pts/1\" with tty command, then\n"
"                          display the execution contex using the commands : \n";



int createalive;

sem_t fnopen;

sem_t recnb ;

char bf[120];

void* create ( ) //no argument
{
    char fn[] = "log.txt";
createalive=1;
  int student_destination;
  int file_destination;
  printf("create>\tTID <%u> \tPid <%d>\tPPid <%d> running\n", pthread_self (), getpid(), getppid());
  

        // create the output file & force outputs to be written on disk
         if((file_destination = open( fn, O_WRONLY | O_TRUNC | O_CREAT | O_SYNC, S_IRUSR  |S_IWUSR)) == -1)
            {perror("open2"); exit(2);}
         sem_post(&fnopen);

      do{

student_destination=(fgets(bf, sizeof(bf)-1, stdin) != NULL);
if(student_destination != 1){
student_destination=-1;
}

write(file_destination, bf, strlen(bf)); 
fflush(stdin);
sem_post(&recnb);
}while (student_destination != EOF);

createalive=0;
       close(file_destination);

  printf("\ncreate>\tTID <%u> exits", pthread_self () );
  return NULL; 

}

void *list(){
 
    char fn[] = "log.txt";

	    int fpos;    
        FILE *ptw;         
        FILE *inp;         
        struct stat file;  


printf("List>\tTID <%u> \tPid <%d>\tPPid <%d> running\n", pthread_self(), getpid(), getppid());




while( (ptw = fopen( "/dev/pts/1", "w")) == NULL)
            {perror("open new terminal"); sleep(1);}



sem_wait(&fnopen);

if( (inp = fopen( fn, "r")) == NULL)
            {perror("open2"); exit(2);}


fprintf(ptw,"\nlist thread starts now its monitoring ... \n");
do{

		
            if (stat(fn, &file) < 0)
                { perror("stat error"); exit(4);}
            // test if new data entered
		fpos= ftell(inp);

            while(sem_trywait(&recnb)==0){

                if ( (fgets (bf, 120-1, inp) ) == NULL) 
                     {perror("read2"); exit(6);}
		
                fputs (bf, ptw) ; 
            }
                sleep(1);    // sleep n seconds
        }while (createalive > 0 ); 


printf("\nlist>\tTID <%u> exits", pthread_self () );
fclose(ptw);
fclose(inp);
return NULL;


}

int main()
{
   puts(banner);
   printf("$ ps -Lf -p %d\n",getpid());
   printf("$ pstree -p %d\n",getppid());
   printf("click y after you have done all.\n  ");
   sem_init(&fnopen, 0, 0);
   sem_init(&recnb, 0, 0);


  char fn[]="log.txt";
  pthread_t pTID, myThreads1 , myThreads2;

  printf("\nMain>\tTID <%u>", pthread_self () );  
  printf("\tPid <%d>\tPPid <%d>\n", getpid(), getppid()); 

  if ( pthread_create(&myThreads1, NULL, create, NULL) != 0 )
      { perror ("pthread_crate");  return(1); }
  sleep(1);   // to let the thread run
  
 
	if ( pthread_create(&myThreads2, NULL, list, NULL) != 0 )
      { perror ("pthread_crate");  return(1); }
       sleep(1);

  pthread_join(myThreads1, NULL); /* wait for thread */  
  pthread_join(myThreads2, NULL); 
  printf("\nMain>\tTID <%u> exits\n", pthread_self () );
  pthread_exit(0);
  return 0;
}
