#define _CRT_SECURE_NO_WARNINGS
#include <ctype.h>
#include <stdio.h>
#define KEY '&'



void encryptDecrypt(char inpString[])
{

    char xorKey = '&';

    // calculate length of input string
    int len = strlen(inpString);

    // perform XOR operation of key
    // with every character in string
    for (int i = 0; i < len; i++)
    {
        inpString[i] = inpString[i] ^ xorKey;
        printf("");
      
    }
}

// Driver program to test above function
int main()
{   FILE* fptr;
    char SampleString[1000];
    fgets(SampleString, 1000, stdin);
    fptr = fopen("Recycle.txt", "w");

    // Encrypt the string
    printf("Encrypted String: ");
    encryptDecrypt(SampleString);
    printf("\n");
    fprintf(fptr, "%s", SampleString);

    // Decrypt the string
    printf("Decrypted String: ");
    encryptDecrypt(SampleString);
    
    fclose(fptr);
    return 0;
}
