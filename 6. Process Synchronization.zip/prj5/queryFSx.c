/*Nasibullah Qarizada - 1900004691*/




#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>     // Low Level open
#include <sys/stat.h>
#include <grp.h>
#include <time.h>
#include <string.h>
#include <unistd.h>    //API read. write, seek



typedef struct { // idx file record structure
	char actname [32+1];   // account name string
	long int pwdoffset;    // passwd file offset
} IdxRec, *pIdxRec;


void h_sdir(char in[],char uname[]) {//finds and displays the home directory and login shell

	struct group *cls;
	

	if((cls=getgrnam(uname))==NULL)
		perror("getgrnam() error");
	else{
		printf("\nGr_name: %s  ",cls->gr_name);}

	char z[25], s[15];
	int  x = 0,y;
	
	while (in[x] != '\0') {//reaches the start of the home directory
		if (in[x] == '/')
			break;
		x++;
	}

	for ( y = 0; in[x] != ':'; y++,x++) {
		z[y] = in[x];

	}
	z[y] = '\0';
	printf("\nHome: %s\n", z);
	x++;
	for ( y = 0; in[x] != '\0'; y++,x++) {
		s[y] = in[x];
	}
	s[y] = '\0';
        
	printf("Login: %s\n", s);//prints the login shell

}


int fun(int array[],IdxRec* IdxTab, char* name , int length){//find the user required
	int x=0, start = 0;
	while(x < length){
		if(strcmp(name,IdxTab[array[x]].actname)==0)
			{
				start = 1;
				break;
		}
		x++;
	}
	if(start == 0) 
		return -1;

		return array[x];
}

  
int main()
{
	long int pos;		//  byte offset in "./pwd.fix"
	int pwdrel; 		//  length of record in "./pwd.fix" file
	int fdpwd;	//  file descriptor of "./pwd.fix"			
	int fdidx;			//  file descriptor of "./pwd.idx" 
	pIdxRec IdxTab;		//  index table pointer 
	char uname[32+1+1];
	char *buf;
	int *p;	
	struct stat idx, fix; // Data structures used by stat function
	struct group *pgr;   // pointer to data structure returnes by getgrid 
	int nbusr, i, j;
	
	// get the size of the index file and compute the number of entries
	if (stat("./pwd.idx", &idx) < 0)
		{ puts("stat error"); return 1;}
	nbusr = idx.st_size / sizeof(IdxRec); // nb. of accounts
	// allocate the idx structure table IdxTab [nbsusr]
	if ( ( IdxTab = malloc(idx.st_size) ) == NULL) 
		{ puts("buffer allocation error"); return 2; }
	
	// get the size of data file and compute the record length
	if (stat("./pwd.fix", &fix) < 0)
		{ puts("stat error"); return 3;}
	pwdrel = fix.st_size / nbusr;    // "./pwd.fix" record length  
	// allocate input buffer to read "./pwd.fix" records
	if ( ( buf = malloc(pwdrel) ) == NULL) 
		{ puts("buffer allocation error"); return 4; }
	
	fdidx = open("pwd.idx", O_RDONLY);

	printf("enter the account name\n  ");

	if (scanf_s("%s", uname) == EOF) { 
		perror("Error no user found");
		return 1;
	}
	
	if (pread(fdidx, (void *) IdxTab, (sizeof(IdxRec) * idx.st_size), 0) == -1)
	{
		perror("./idx write error: "); return -4;
	}
	
	close(fdidx);

	p=(int )malloc(sizeof(int)(idx.st_size / sizeof(IdxRec)));

	for(int q=0;q<(idx.st_size / sizeof(IdxRec));q++){

	p[q]=q;	

	}

	for(int q=0;q<(idx.st_size / sizeof(IdxRec));q++){

	int n=rand()%(idx.st_size / sizeof(IdxRec)),tmp;
	tmp=p[n];
	p[n]=p[q];
	p[q]=tmp;

	}
	

	pos=fun(p,IdxTab,uname,idx.st_size);
	


		fdpwd = open("pwd.fix", O_RDONLY);
		
			int offset_ = IdxTab[pos].pwdoffset;
			
			char c = (char) malloc(sizeof(char)*pwdrel);
			pread(fdpwd, (void*)c, pwdrel, offset_);

			h_sdir(c,uname);

	
		
	

	printf("\npwd.fix file has <%d> records of <%d> bytes\n", nbusr,pwdrel);
	


	return 0;
}
