





//Nasibullah Qarizada - 1900004691

#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

int in;
int acc = 0;
FILE *pts;


sem_t s_acc;

void * Atm()  
{

	int deposit = 0;

  	fprintf(pts,"ATM thread(%u) started\n", pthread_self());    

	while ( in != EOF){
		printf("\nmain> Enter amount or `ctrl+d` to end: ");
		   in = scanf("%d", &deposit) ; 

	sem_wait(&s_acc);
		
	if((deposit+acc)<0){
	printf("atm> insufficient balance %d\n",acc);

	}else{
	acc = acc + deposit; 
	}
      

	printf("\natm>balance = %d", acc);
	sem_post(&s_acc);
  	}
	in=-1;

	printf("\natm> signing off\n");

}

void * Pay()   
{
	while(in != EOF){	
	sleep(12);	
	sem_wait(&s_acc);	
	acc=acc+10;
	fprintf(pts,"\n\tpay> +10 account = %d\n",acc);
	sem_post(&s_acc);
	}
    	fprintf(pts,"\npay> signing off");
}



void * Bill()   
{

	while(in != EOF){
	sleep(3);
	
	sem_wait(&s_acc);
	acc = acc-1;
	fprintf(pts,"\nbill> -1 account = %d",acc);
	sem_post(&s_acc);
	}

    	fprintf(pts,"\nbill> signing off\n");

}


int main()
{

   sem_init(&s_acc, 0, 1);

    pthread_t  TID1, TID2, TID3;   
      
    while( (pts = fopen( "/dev/pts/1", "w")) == NULL)
            {
		perror("open new terminal");
	sleep(5);
	}           
     
    if(pthread_create(&TID1, NULL, Atm, NULL)) 
	{ // could not create display thread 
                perror("pthread_create"); 
				return(1);
	}
 
    if(pthread_create(&TID2, NULL, Pay, NULL)) 
	{ // could not create display thread 
                perror("pthread_create");
				return(1); 
	}
	
    if(pthread_create(&TID3, NULL, Bill, NULL)) 
	{ // could not create display thread 
                perror("pthread_create"); 
				return(1); 
	}
	 

		
	pthread_join(TID1, NULL); 
	
	pthread_join(TID2, NULL);

	pthread_join(TID3, NULL); 
	     
 
   printf("\n main thread> exiting\n");	

   return 0;
}
