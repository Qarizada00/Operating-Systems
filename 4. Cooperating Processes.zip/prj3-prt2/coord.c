



//Nasibullah Qarizada - 1900004691

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#define nbslots 4

typedef struct{
	char type;
	int amount;
	int oldbal;
	int newbal;

}LogRec, *pLogRec;

LogRec cq[nbslots];

sem_t s_cirq;
sem_t s_ept;
sem_t s_full;

int in=0;
int out=0;
int ab=0;
int count=0;
int on;

int acc = 0;
FILE *pts,*pts2;

void * atm()   
{

	int dep_amount = 0;
	sem_wait(&s_ept);
  	fprintf(pts,"ATM thread(%u) started\n", pthread_self());    

	while ( on != EOF){
		printf("\nmain> Enter amount or `ctrl+d` to end: ");
		   on = scanf("%d", &dep_amount) ; 

	if(dep_amount+acc<0){ ("atm> insufficient balance %d\n",acc); }
	else{ 
	cq[in].type = 'A';
	cq[in].oldbal= acc;
	cq[in].amount = dep_amount;
	acc += dep_amount; }
	cq[in].newbal = acc;
	printf("atm> balance= %d\n", acc);

	sem_wait(&s_cirq);

	in = (in + 1) % nbslots; 

	sem_post(&s_cirq);
	sem_post(&s_full);
    }

	printf("\natm> EOF, signing off\n");
}

void * pay()   
{
    	fprintf(pts,"\n\t\t\t\tpay> started\n"); 

	while(on != EOF){
	sem_wait(&s_ept);
	sleep(12);
	
	sem_wait(&s_cirq);
	cq[in].type='p';
	cq[in].amount=10;
	cq[in].oldbal=acc;
	acc+=10;
	cq[in].newbal=acc;
	in=(in+1)%nbslots; 
fprintf(pts,"\n\t\t\t\tpay> +10 account = %d\n",acc);
	
        sem_post(&s_cirq);
sem_post(&s_full);
	}


    	fprintf(pts,"\npay> EOF, signing off");
}

void * bill()   
{
     	fprintf(pts,"\nbill> started\n");

	while(on != EOF){
sem_wait(&s_ept);
	
	sem_wait(&s_cirq);
sleep(3);

cq[in].type= 'B';
cq[in].oldbal= acc;
cq[in].amount= -1;

acc-=1;

cq[in].newbal= acc;
	in=(in+1)%nbslots; 

	fprintf(pts,"\nbill> -1 account = %d",acc);

        sem_post(&s_cirq);
sem_post(&s_full);
	}

    	fprintf(pts,"\nbill> EOF , signing off\n");	
}


void* arch() {
char c; int new, old, de;

	fprintf(pts2,"\narch> started\n");
    do {
	    
	while(sem_trywait(&s_full)){
	sem_wait(&s_cirq);
	
	 c = cq[out].type;
	 de = cq[out].amount;
	 new = cq[out].newbal;
	 old = cq[out].oldbal;

	
	out=(out+1)%nbslots;


        sem_post(&s_cirq);
	sem_post(&s_ept);
fprintf(pts2,"arch> %c\t%d\t%d\t%d\n",c, de, old, new);
	sleep(3);    
    
}

	sleep(1);    
	
    }while(on != EOF);
fprintf(pts2,"\narch> signing off\n");        
}


int main() {

    sem_init(&s_cirq, 0, 1);
    sem_init(&s_full, 0, 0);
    sem_init(&s_ept, 0, nbslots);

    int i;
    pthread_t  t1, t2, t3, t4;  
       
    while( (pts = fopen( "/dev/pts/1", "w")) == NULL)
            {
		perror("open new terminal");
		sleep(5);
	}   
 
    while( (pts2 = fopen( "/dev/pts/2", "w")) == NULL)
            {
		perror("open new terminal");
		sleep(5);
	}    
       
   
    if(pthread_create(&t1, NULL, atm, NULL)) 
	{ 
                perror("pthread_create"); 
				return(1);
	}
 if(pthread_create(&t2, NULL, bill, NULL)) 
 { 
                perror("pthread_create"); 
				return(1); 
 }

               
 if(pthread_create(&t3, NULL, pay, NULL))  
 { 
                perror("pthread_create");
				return(1);
 }
sleep(2);
            if (pthread_create(&t4, NULL, &arch, NULL)) 
			{
                perror("Failed to create thread");
				return(2);
            }

	pthread_join(t1, NULL); 
	pthread_join(t2, NULL); 
	pthread_join(t3, NULL); 
	pthread_join(t4, NULL);

	printf("\n main thread> exiting\n");	

    	return 0;
}
