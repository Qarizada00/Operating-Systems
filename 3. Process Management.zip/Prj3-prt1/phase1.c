#include <stdio.h>
#include <stdlib.h>     
#include <string.h>
#include <unistd.h>      
#include <fcntl.h> 



char* convertIntegerToChar(int N)
{

    // Count digits in number N
    int m = N;
    int digit = 0;
    while (m) {

        // Increment number of digits
        digit++;

        // Truncate the last
        // digit from the number
        m /= 10;
    }

    // Declare char array for result
    char* arr;

    // Declare duplicate char array
    char arr1[digit];

    // Memory allocation of array
    arr = (char*)malloc(digit);

    // Separating integer into digits and
    // accommodate it to character array
    int index = 0;
    while (N) {

        // Separate last digit from
        // the number and add ASCII
        // value of character '0' is 48
        arr1[++index] = N % 10 + '0';

        // Truncate the last
        // digit from the number
        N /= 10;
    }

    // Reverse the array for result
    int i;
    for (i = 0; i < index; i++) {
        arr[i] = arr1[index - i];
    }

    // Char array truncate by null
    arr[i] = '\0';

    // Return char array
    return (char*)arr;
}


int main()
{

printf("Username: %s\n", getenv("USER"));

printf("Working dir: %s\n", getcwd(cwd, sizeof(cwd));

printf("Process id: %d\n",getpid());

printf("parent id: %d\n",getppid());

char *pid;


pid = convertIntegerToChar(getpid());

char loca[30]= "ls -l /proc/";

strncat(loca,pid,sizeof(pid));

strncat(loca,"/fd/",5);

int stdout = open("data.txt", O_WRONLY | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO);

printf("copy loaded and excecuted\n");

dup2(stdout,STDOUT_FILENO);

close(stdout);

system(loca);

char *progarm[]={"./copy",NULL};

execv(progarm[0],progarm);

return 0;

}
