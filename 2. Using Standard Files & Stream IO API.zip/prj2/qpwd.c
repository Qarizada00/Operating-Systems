

//NasibullahQarizada-1900004691

#define _CRT_SECURE_NO_WARNINGS 
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


void homeshell(char in[]) { // it prints out home directory and login shell

	char dri[20], shell_login[20];
	int a = 0, b = 0, c;

	for (; a != 5; b++) {
		if (in[b] == ':')
			a++;
	}

	for (c = 0; in[b] != ':'; c++, b++) {
		dri[c] = in[b];
	}
	dri[c] = '\0';

	for (c = 0; in[b] != '\0'; c++, b++) {
		shell_login[c] = in[b];
	}
	shell_login[c] = '\0';

	printf("Home dir : %s\n", dri);  //it prints directry home
	printf("Shell login : %s\n", shell_login); //it prints login shell

}

int main(int size,char* input[]) {
	
	int n, i;

	char SortTab[101 ][1024 ]; // user account records
	FILE* file;
	file = fopen("./passwd.srt", "r");


	for (n = 0; n < 101; n++) {
		if (fgets(SortTab[n], 1024, file) == NULL) //it takes the file contents and stores it in the sort tab.
			break;
	}


	char token[30],tmp[1024];
	const char deli[] = ":";
	for (int x = 0; x<size; x++) {

		for (i = 0; i < n; i++) {
			strcpy(tmp, SortTab[i]);
			strcpy(token, strtok(tmp, deli));
            
			if (strcmp(token, input[x]) == 0) {
				homeshell(SortTab[i]);
				
			}

		}


	}


	return 0;
}

