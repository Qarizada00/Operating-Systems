



//NasibullahQarizada-1900004691

/* pwd_sort.c
   - sorts ./tstpwd file a local copy of /etc/passwd
			in ascending order of account name field
   - assumes that "/etc/passwd":
	   max.record length is 1023 bytes
	   max. number of records is 100
   - uses stream I/O API
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

// actcmp returns 0 if s==t, <0 if s<t, >0 if s>t
int actcmp(char* s, char* t)
{
	for (; *s == *t; s++, t++)
		if (*s == ':') return 0; // s = t
	if (*s == ':') return -1;   // s < t
	if (*t == ':') return +1;   // s > t
	return *s - *t;
}

#define i1024  1023  // max.record lengt in "/etc/passwd"
#define i101  100   // max.# of records in "/etc/passwd"     

int main()
{
	char SortTab[i101 + 1][i1024 + 1]; // user account records
	int* SortIdx = malloc(sizeof(int) * (i101 + 1)); 
	int nbusr, i, j, tmp;
	FILE* fppwd;		//  -->   ./passwd
	FILE* file;

	if ((fppwd = fopen("./tstpwd", "r")) == NULL)
	{
		perror("./tstpwd: "); 
		return 1;
	}
	if ((file = fopen("./passwd.srt", "w++")) == NULL)
	{
		perror("./passwd.srt: "); 
		return 1;
	}

	// fgets reads a ./passwd record including '\n'
	//       stores it as a string adding by a '\0'
	i = 0;
	for (nbusr = 0; nbusr < i101; nbusr++) {
		SortIdx[nbusr] = nbusr;  // set index to records order
		if (fgets(SortTab[nbusr], i1024, fppwd) == NULL)
			break;
	}

	// bubble sort TabIdx in ascending order of account names
	for (i = 0; i < nbusr - 2; i++)
		for (j = i + 1; j < nbusr - 1; j++)
			if (actcmp((char*)(SortTab + SortIdx[i]), (char*)(SortTab + SortIdx[j])) > 0) {
				tmp = SortIdx[i];
				SortIdx[i] = SortIdx[j];     // swap entries i and j
				SortIdx[j] = tmp;
			}

	// display account records in ascending order
	for (i = 0; i < nbusr; i++) {
		printf("acct[%d]: %s", i, SortTab[SortIdx[i]]);
		fprintf(file, "acct[%d]: %s", i, SortTab[SortIdx[i]]);
	}
	return 0;
}
